#!/bin/bash

TARGET_FILE="src/graphics/graphics_engine.hpp"
BACKUP_FILE="src/graphics/graphics_engine.hpp.bak"

echo "==========================================================="
echo "   Applying UI Hooks Patch to Graphics Engine Header"
echo "==========================================================="

if [ ! -f "$TARGET_FILE" ]; then
    echo "[Error] $TARGET_FILE not found! Are you in the workspace root?"
    exit 1
fi

# Create a safe backup
cp "$TARGET_FILE" "$BACKUP_FILE"
echo "[System] Backed up original header to $BACKUP_FILE"

# Use AWK to intelligently insert the UI hooks right after end_frame()
# The 'found' flag ensures it is idempotent (running it twice won't duplicate the lines)
awk '
/void begin_ui\(\);/ { found=1 }
{ lines[NR] = $0 }
END {
    for (i=1; i<=NR; i++) {
        print lines[i]
        if (lines[i] ~ /void end_frame\(\);/ && !found) {
            print ""
            print "    // ImGui Context Hooks"
            print "    void begin_ui();"
            print "    void end_ui();"
        }
    }
}
' "$TARGET_FILE" > "${TARGET_FILE}.tmp"

# Overwrite original with the patched version
mv "${TARGET_FILE}.tmp" "$TARGET_FILE"

echo "[Success] Successfully patched $TARGET_FILE!"
echo "You can now run ./build.sh."
