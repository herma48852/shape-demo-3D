#!/bin/bash

TARGET_FILE="src/main.cpp"
BACKUP_FILE="src/main.cpp.bak2"

echo "==========================================================="
echo "   Applying Full Stack Physics & DDS Patch to Main"
echo "==========================================================="

if [ -f "$TARGET_FILE" ]; then
    echo "[System] Backing up Phase 2 Main to $BACKUP_FILE..."
    cp "$TARGET_FILE" "$BACKUP_FILE"
fi

echo "[System] Writing updated main.cpp..."
cat << 'EOF' > "$TARGET_FILE"
/*****************************************************************************/
/* (c) Copyright, Real-Time Innovations, All rights reserved.                */
/* */
/* Permission to modify and use for internal purposes granted.               */
/* This software is provided "as is", without warranty, express or implied.  */
/* */
/*****************************************************************************/

#define _USE_MATH_DEFINES
#include <iostream>
#include <chrono>
#include <thread>
#include <cmath>
#include <map>
#include <vector>
#include <string>

#include "dds_manager.hpp"
#include "graphics_engine.hpp"
#include "thread_queue.hpp"

// Suppress strict non-trivial memory warnings from modern compilers
#if defined(__clang__) || defined(__GNUC__)
    #pragma GCC diagnostic push
    #pragma GCC diagnostic ignored "-Wnontrivial-memcall"
#endif
#include "imgui.h"
#if defined(__clang__) || defined(__GNUC__)
    #pragma GCC diagnostic pop
#endif

// --- PHASE 4: Dynamic State Definitions ---
enum class TrajectoryType { PLANE_Z125, BOUNCE_3D, ORBIT };

struct LocalPublisher {
    std::string id;
    std::string shape;
    std::string color;
    int size;
    int publish_hz;
    TrajectoryType trajectory;

    // Kinematics
    float x, y, z;
    float vx, vy, vz;
    std::chrono::steady_clock::time_point last_publish_time;
};

struct LocalSubscriber {
    std::string id;
    std::string target_shape;
    std::string color_filter;
};
// ------------------------------------------

// Structured record tracking active coordinates inside the visualizer mapping layer
struct VisualizerShapeInstance {
    std::string shape_topic;
    std::string color;
    float current_x = 125.0f;
    float current_y = 125.0f;
    float current_z = 125.0f;
    int32_t size = 15;
    std::chrono::steady_clock::time_point last_sample_time;
};

// Maps color keys to standard floating-point RGB representations
void get_color_rgb(const std::string& color_str, float& r, float& g, float& b) {
    if (color_str == "BLUE" || color_str == "#3b82f6") { r = 0.23f; g = 0.51f; b = 0.96f; }
    else if (color_str == "RED" || color_str == "#ef4444") { r = 0.94f; g = 0.27f; b = 0.27f; }
    else if (color_str == "YELLOW" || color_str == "#eab308") { r = 0.92f; g = 0.70f; b = 0.03f; }
    else if (color_str == "GREEN" || color_str == "#10b981") { r = 0.06f; g = 0.73f; b = 0.51f; }
    else if (color_str == "PURPLE" || color_str == "#a855f7") { r = 0.66f; g = 0.33f; b = 0.97f; }
    else { r = 0.8f; g = 0.8f; b = 0.8f; } 
}

int main(int argc, char* argv[]) {
    std::cout << "====================================================================\n";
    std::cout << "   RTI Connext DDS 3D Shapes Visualizer (macOS Native App)\n";
    std::cout << "====================================================================\n" << std::endl;

    int domain_id = 0;
    if (argc > 1) {
        try {
            domain_id = std::stoi(argv[1]);
        } catch (const std::exception&) {
            std::cerr << "[Warning] Invalid Domain ID argument. Defaulting to 0." << std::endl;
        }
    }

    std::cout << "[System] Bootstrapping DDS Interface on Domain " << domain_id << "..." << std::endl;

    ThreadSafeSampleQueue sample_queue;
    DdsSubsystemManager dds_manager;
    dds_manager.initialize_dds_domain(domain_id, &sample_queue);

    std::cout << "[System] Initializing Hardware-Accelerated Graphics Engine..." << std::endl;
    
    GraphicsEngine graphics;
    if (!graphics.initialize(1280, 720, "RTI DDS 3D Shapes Workspace")) {
        std::cerr << "[Fatal] OpenGL context initialization failed." << std::endl;
        return EXIT_FAILURE;
    }

    // --- State Vectors ---
    std::vector<LocalPublisher> active_publishers;
    std::vector<LocalSubscriber> active_subscribers;
    std::map<std::string, VisualizerShapeInstance> shape_registry;
    
    // ImGui Publisher Form State Variables
    const char* shapes[] = { "Square", "Circle", "Triangle" };
    int shape_idx = 0;
    const char* colors[] = { "BLUE", "RED", "YELLOW", "GREEN", "PURPLE" };
    int color_idx = 0;
    int size_val = 15;
    const char* trajectories[] = { "PLANE_Z125", "BOUNCE_3D", "ORBIT" };
    int traj_idx = 0;
    int publish_hz = 16;

    // ImGui Subscriber Form State Variables
    const char* sub_shapes[] = { "All", "Square", "Circle", "Triangle" };
    int sub_shape_idx = 0;
    const char* sub_colors[] = { "All", "BLUE", "RED", "YELLOW", "GREEN", "PURPLE" };
    int sub_color_idx = 0;
    // ------------------------------

    double global_time_counter = 0.0;
    auto last_frame_time = std::chrono::steady_clock::now();

    std::cout << "[System] Application successfully loaded. Workspace ready!" << std::endl;

    while (graphics.is_running()) {
        auto current_time = std::chrono::steady_clock::now();
        std::chrono::duration<double> dt_dur = current_time - last_frame_time;
        double dt = dt_dur.count(); // Delta time in seconds
        last_frame_time = current_time;

        global_time_counter += dt;
        double dt_ms = dt * 1000.0; // Scaled for 60Hz physics baseline

        // --- Kinematics & DDS Publish Loop ---
        for (size_t i = 0; i < active_publishers.size(); ++i) {
            auto& pub = active_publishers[i];
            
            if (pub.trajectory == TrajectoryType::PLANE_Z125) {
                pub.x += pub.vx * (dt_ms / 16.6f);
                pub.y += pub.vy * (dt_ms / 16.6f);
                pub.z = 125.0f;
            } else if (pub.trajectory == TrajectoryType::BOUNCE_3D) {
                pub.x += pub.vx * (dt_ms / 16.6f);
                pub.y += pub.vy * (dt_ms / 16.6f);
                pub.z += pub.vz * (dt_ms / 16.6f);
            } else if (pub.trajectory == TrajectoryType::ORBIT) {
                float radius = 80.0f;
                float speed = 2.0f; 
                float offset = i * 2.0f; // Prevent multi-orbit collisions
                pub.x = 125.0f + std::cos(global_time_counter * speed + offset) * radius;
                pub.y = 125.0f + std::sin(global_time_counter * speed + offset) * radius;
                pub.z = 125.0f + std::sin(global_time_counter * speed * 2.0f) * 40.0f;
            }

            // Boundary Checks
            float bound = 250.0f;
            float half = pub.size / 2.0f;
            if (pub.x < half) { pub.x = half; pub.vx *= -1; }
            if (pub.x > bound - half) { pub.x = bound - half; pub.vx *= -1; }
            if (pub.y < half) { pub.y = half; pub.vy *= -1; }
            if (pub.y > bound - half) { pub.y = bound - half; pub.vy *= -1; }
            if (pub.trajectory == TrajectoryType::BOUNCE_3D) {
                if (pub.z < half) { pub.z = half; pub.vz *= -1; }
                if (pub.z > bound - half) { pub.z = bound - half; pub.vz *= -1; }
            }

            // Execute DDS Network Publication based on set Hz limit
            std::chrono::duration<double> t_since_pub = current_time - pub.last_publish_time;
            if (t_since_pub.count() >= (1.0 / pub.publish_hz)) {
                pub.last_publish_time = current_time;
                dds_manager.write_shape_sample(pub.shape, pub.color, 
                                               static_cast<int32_t>(pub.x), 
                                               static_cast<int32_t>(pub.y), 
                                               static_cast<int32_t>(pub.z), 
                                               pub.size, ShapeFillKind::SOLID_FILL, 0.0f);
            }
        }

        // --- DDS Telemetry Drainage Loop ---
        auto incoming_samples = sample_queue.drain_queue();
        for (const auto& sample : incoming_samples) {
            std::string key = sample.color + "_" + dds_manager.map_ui_to_dds_topic(sample.color);
            VisualizerShapeInstance& inst = shape_registry[key];
            inst.color = sample.color;
            inst.size = sample.shapesize;
            inst.current_x = static_cast<float>(sample.x);
            inst.current_y = static_cast<float>(sample.y);
            inst.current_z = static_cast<float>(sample.z);
            inst.last_sample_time = current_time;
        }

        // --- OpenGL Render Frame ---
        graphics.begin_frame();
        graphics.draw_coordinate_grid();

        // 1. Draw Local Publishers (Solid Shading)
        for (const auto& pub : active_publishers) {
            float r, g, b;
            get_color_rgb(pub.color, r, g, b);
            if (pub.shape == "Square") graphics.draw_cube(pub.x, pub.y, pub.z, pub.size, r, g, b, false);
            else if (pub.shape == "Circle") graphics.draw_sphere(pub.x, pub.y, pub.z, pub.size / 2.0f, r, g, b, false);
            else if (pub.shape == "Triangle") graphics.draw_tetrahedron(pub.x, pub.y, pub.z, pub.size, r, g, b, false);
        }

        // 2. Draw Received Telemetry Subscribers (Glowing Wireframes)
        for (auto it = shape_registry.begin(); it != shape_registry.end(); ) {
            std::chrono::duration<double> age = current_time - it->second.last_sample_time;
            if (age.count() > 3.0) {
                it = shape_registry.erase(it);
                continue;
            }

            float r, g, b;
            get_color_rgb(it->second.color, r, g, b);
            std::string normalized_topic = dds_manager.map_ui_to_dds_topic(it->first);
            float draw_size = it->second.size * 1.25f; // Draw slightly larger to cage the solid object
            
            if (normalized_topic == "Square") graphics.draw_cube(it->second.current_x, it->second.current_y, it->second.current_z, draw_size, r, g, b, true);
            else if (normalized_topic == "Circle") graphics.draw_sphere(it->second.current_x, it->second.current_y, it->second.current_z, draw_size / 2.0f, r, g, b, true);
            else if (normalized_topic == "Triangle") graphics.draw_tetrahedron(it->second.current_x, it->second.current_y, it->second.current_z, draw_size, r, g, b, true);
            
            ++it;
        }

        // --- ImGui UI Generation ---
        graphics.begin_ui();

        ImGui::SetNextWindowPos(ImVec2(10, 10), ImGuiCond_FirstUseEver);
        ImGui::SetNextWindowSize(ImVec2(350, 500), ImGuiCond_FirstUseEver);
        ImGui::Begin("RTI Connext 3D Workspace", nullptr, ImGuiWindowFlags_NoCollapse);
        
        // PUBLISHER FORM
        ImGui::TextColored(ImVec4(0.4f, 0.8f, 1.0f, 1.0f), "Create DataWriter (Publisher)");
        ImGui::Separator();
        ImGui::Combo("Shape##pub", &shape_idx, shapes, IM_ARRAYSIZE(shapes));
        ImGui::Combo("Color##pub", &color_idx, colors, IM_ARRAYSIZE(colors));
        ImGui::SliderInt("Size##pub", &size_val, 10, 30);
        ImGui::Combo("Trajectory", &traj_idx, trajectories, IM_ARRAYSIZE(trajectories));
        ImGui::SliderInt("Publish Hz", &publish_hz, 1, 60);

        if (ImGui::Button("Initialize DataWriter Instance", ImVec2(-1, 30))) {
            LocalPublisher pub;
            pub.id = "pub_" + std::to_string(std::chrono::system_clock::now().time_since_epoch().count());
            pub.shape = shapes[shape_idx];
            pub.color = colors[color_idx];
            pub.size = size_val;
            pub.publish_hz = publish_hz;
            pub.trajectory = static_cast<TrajectoryType>(traj_idx);
            
            pub.x = 125.0f; pub.y = 125.0f; pub.z = 125.0f;
            pub.vx = (std::rand() % 100 / 50.0f) - 1.0f; 
            pub.vy = (std::rand() % 100 / 50.0f) - 1.0f; 
            pub.vz = (pub.trajectory == TrajectoryType::BOUNCE_3D) ? 2.5f : 0.0f;
            pub.last_publish_time = std::chrono::steady_clock::now();

            dds_manager.create_writer(pub.shape, pub.color);
            active_publishers.push_back(pub);
        }

        ImGui::Spacing();
        ImGui::Spacing();

        // SUBSCRIBER FORM
        ImGui::TextColored(ImVec4(0.4f, 1.0f, 0.4f, 1.0f), "Create DataReader (Subscriber)");
        ImGui::Separator();
        ImGui::Combo("Shape##sub", &sub_shape_idx, sub_shapes, IM_ARRAYSIZE(sub_shapes));
        ImGui::Combo("Color##sub", &sub_color_idx, sub_colors, IM_ARRAYSIZE(sub_colors));
        
        if (ImGui::Button("Initialize DataReader Instance", ImVec2(-1, 30))) {
            LocalSubscriber sub;
            sub.id = "sub_" + std::to_string(std::chrono::system_clock::now().time_since_epoch().count());
            sub.target_shape = sub_shapes[sub_shape_idx];
            sub.color_filter = sub_colors[sub_color_idx];
            
            if (sub.target_shape == "All") {
                dds_manager.create_reader("Square", sub.color_filter);
                dds_manager.create_reader("Circle", sub.color_filter);
                dds_manager.create_reader("Triangle", sub.color_filter);
            } else {
                dds_manager.create_reader(sub.target_shape, sub.color_filter);
            }
            active_subscribers.push_back(sub);
        }

        ImGui::Spacing();
        ImGui::Spacing();
        ImGui::Separator();
        ImGui::Text("Active Entities:");
        
        // REGISTRY TABLE
        if (ImGui::BeginTable("EntitiesTable", 3, ImGuiTableFlags_Borders | ImGuiTableFlags_RowBg | ImGuiTableFlags_SizingFixedFit)) {
            ImGui::TableSetupColumn("Type", ImGuiTableColumnFlags_WidthFixed, 40.0f);
            ImGui::TableSetupColumn("Details", ImGuiTableColumnFlags_WidthStretch);
            ImGui::TableSetupColumn("Action", ImGuiTableColumnFlags_WidthFixed, 50.0f);
            ImGui::TableHeadersRow();

            // Render Publishers
            for (size_t i = 0; i < active_publishers.size(); ) {
                ImGui::TableNextRow();
                ImGui::TableNextColumn();
                ImGui::TextColored(ImVec4(0.4f, 0.8f, 1.0f, 1.0f), "PUB");
                ImGui::TableNextColumn();
                ImGui::Text("%s (%s)", active_publishers[i].shape.c_str(), active_publishers[i].color.c_str());
                ImGui::TableNextColumn();
                
                ImGui::PushID(("del_pub_" + active_publishers[i].id).c_str());
                if (ImGui::Button("Delete")) {
                    dds_manager.delete_writer(active_publishers[i].shape, active_publishers[i].color);
                    active_publishers.erase(active_publishers.begin() + i);
                } else {
                    ++i;
                }
                ImGui::PopID();
            }

            // Render Subscribers
            for (size_t i = 0; i < active_subscribers.size(); ) {
                ImGui::TableNextRow();
                ImGui::TableNextColumn();
                ImGui::TextColored(ImVec4(0.4f, 1.0f, 0.4f, 1.0f), "SUB");
                ImGui::TableNextColumn();
                ImGui::Text("%s (%s)", active_subscribers[i].target_shape.c_str(), active_subscribers[i].color_filter.c_str());
                ImGui::TableNextColumn();
                
                ImGui::PushID(("del_sub_" + active_subscribers[i].id).c_str());
                if (ImGui::Button("Delete")) {
                    if (active_subscribers[i].target_shape == "All") {
                        // Note: Removing overlapping generic readers for demonstration simplicity
                        dds_manager.delete_reader("Square");
                        dds_manager.delete_reader("Circle");
                        dds_manager.delete_reader("Triangle");
                    } else {
                        dds_manager.delete_reader(active_subscribers[i].target_shape);
                    }
                    active_subscribers.erase(active_subscribers.begin() + i);
                } else {
                    ++i;
                }
                ImGui::PopID();
            }
            ImGui::EndTable();
        }
        ImGui::End();
        
        graphics.end_ui();
        // ---------------------------

        graphics.end_frame();

        // Throttle frame rate loosely if V-Sync isn't strictly enforced
        std::this_thread::sleep_for(std::chrono::milliseconds(16));
    }

    dds_manager.shutdown();
    std::cout << "[System] Standard shutdown sequence complete. Application terminated." << std::endl;

    return EXIT_SUCCESS;
}
EOF

echo "[Success] Full stack physics and DDS bindings applied to main.cpp!"
echo "Run ./build.sh and launch. Create a Publisher AND a Subscriber to see the network tracking wireframes!"

